/* 
 * File:   main.c
 * Author: jee22
 *
 * The main function, calls to start
 * the applcation.
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    run_application();

    return (EXIT_SUCCESS);
}

