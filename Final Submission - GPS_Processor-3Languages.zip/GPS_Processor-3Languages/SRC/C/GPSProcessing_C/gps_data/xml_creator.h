/* 
 * File:   xml_creator.h
 * Author: jee22
 *
 * Created on 20 March 2014, 19:01
 */

#ifndef XML_CREATOR_H
#define	XML_CREATOR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* XML_CREATOR_H */

void start_xml();
void end_xml();
void format_date_and_time(time_t date_and_time);
void output_stream(stream * streamer);